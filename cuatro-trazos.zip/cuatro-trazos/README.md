# CUATRO TRAZOS - Arquitectura & Diseño

Página web minimalista y elegante para el estudio de arquitectura y diseño "CUATRO TRAZOS", desarrollada con HTML, CSS y JavaScript puro.

## Características

### Diseño
- **Minimalismo elegante**: Inspirado en el sitio de referencia Cristian Preece
- **Paleta de colores neutral**: Tonos grises, verdes, amarillos y beige
- **Tipografía refinada**: Uso de fuentes serif para títulos y sans-serif para cuerpo
- **Figuras geométricas de fondo**: Rectángulos de colores que representan los "cuatro trazos"
- **Espaciado generoso**: Énfasis en la respiración visual

### Secciones
1. **INICIO**: Presentación principal con logo y descripción
2. **PROYECTOS**: Galería de proyectos en grid responsive
3. **CONTACTO**: Formulario de contacto e información de ubicación

### Funcionalidades
- Navegación suave con scroll automático
- Menú responsive para dispositivos móviles
- Efectos de hover en elementos interactivos
- Animaciones de entrada para tarjetas de proyectos
- Validación de formulario de contacto
- Efecto parallax en el hero
- Indicador activo en navegación según sección visible

## Estructura de Archivos

```
cuatro-trazos/
├── index.html          # Estructura HTML principal
├── styles.css          # Estilos CSS con diseño responsive
├── script.js           # Funcionalidades JavaScript
├── logo.svg            # Logo en formato SVG
└── README.md           # Este archivo
```

## Cómo Usar

### Instalación Local
1. Descargar o clonar los archivos del proyecto
2. Abrir `index.html` en un navegador web
3. No requiere dependencias externas ni servidor

### Personalización

#### Cambiar Colores
Editar las variables CSS en `styles.css`:
```css
:root {
    --color-primary: #2c2c2c;
    --color-green: #b8e6d5;
    --color-yellow: #f4e4a6;
    --color-beige: #f5d5b8;
    --color-gray: #d4d4d4;
}
```

#### Agregar Proyectos
Duplicar la estructura de `.project-card` en `index.html`:
```html
<article class="project-card">
    <div class="project-image">
        <img src="ruta-imagen.jpg" alt="Descripción">
    </div>
    <div class="project-info">
        <h3>Nombre del Proyecto</h3>
        <p>Descripción breve</p>
        <a href="#" class="project-link">Ver más →</a>
    </div>
</article>
```

#### Modificar Información de Contacto
Actualizar los datos en la sección `#contacto`:
- Email: cambiar `info@cuatrotrazos.com`
- Teléfono: cambiar `+56 9 1234 5678`
- Ubicación: cambiar `Santiago, Chile`

## Características Responsive

El sitio está optimizado para:
- **Desktop**: 1200px y superior
- **Tablet**: 768px - 1199px
- **Móvil**: 480px - 767px
- **Móvil pequeño**: Menos de 480px

En dispositivos móviles, el menú de navegación se convierte en un menú hamburguesa interactivo.

## Compatibilidad

- Chrome/Chromium (últimas versiones)
- Firefox (últimas versiones)
- Safari (últimas versiones)
- Edge (últimas versiones)
- Navegadores móviles modernos

## Tecnologías Utilizadas

- **HTML5**: Estructura semántica
- **CSS3**: Diseño responsive, grid, flexbox, animaciones
- **JavaScript Vanilla**: Interactividad sin dependencias externas
- **SVG**: Logo escalable

## Mejoras Futuras

- Integración con backend para envío de formularios
- Galería de proyectos con lightbox
- Blog o sección de publicaciones
- Integración con redes sociales
- Análisis de tráfico (Google Analytics)
- Optimización SEO avanzada
- Multilingual support

## Licencia

Proyecto desarrollado para CUATRO TRAZOS - Arquitectura & Diseño.

## Contacto

Para consultas o modificaciones, contactar a través del formulario en el sitio web.

---

**Última actualización**: Junio 2026
